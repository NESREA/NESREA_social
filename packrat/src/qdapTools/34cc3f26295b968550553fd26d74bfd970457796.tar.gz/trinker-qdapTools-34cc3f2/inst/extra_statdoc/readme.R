<p><img src="https://dl.dropbox.com/u/61803503/qdapicon.png" alt="qdapicon"/><br/>
<a href="https://github.com/trinker/qdapTools">qdapTools</a> is an R package that contains tools associated with the qdap package that may be useful outside of the context of text analysis.</p>

<p>Download the development version of qdapTools <a href="https://github.com/trinker/qdapTools/">here</a> 