.onLoad <- function(libname, pkgname)
  .jpackage("venneuler", "venneuler.jar")
