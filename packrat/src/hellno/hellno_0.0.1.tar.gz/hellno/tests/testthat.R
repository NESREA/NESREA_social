library(testthat)
library(hellno)

test_check("hellno")
