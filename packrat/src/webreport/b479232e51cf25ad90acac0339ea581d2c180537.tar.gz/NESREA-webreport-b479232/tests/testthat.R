library(testthat)
library(webreport)

test_check("webreport")
