#include <R.h>
#include <Rdefines.h>

SEXP null_test() {
    return R_NilValue;
}

SEXP null_test2() {
    return R_NilValue;
}

