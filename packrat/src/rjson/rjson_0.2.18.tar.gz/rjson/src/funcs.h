SEXP fromJSON( SEXP str_in, SEXP unexpected_escape_behavior, SEXP simplify );
SEXP toJSON( SEXP obj );
